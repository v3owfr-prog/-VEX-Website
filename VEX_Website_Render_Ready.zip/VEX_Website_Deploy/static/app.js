document.querySelectorAll('.toggle-row').forEach(row=>row.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){const input=row.querySelector('input');input.checked=!input.checked}}));
