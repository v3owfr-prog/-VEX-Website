import os, secrets, sqlite3, time
from functools import wraps
from pathlib import Path
from urllib.parse import urlencode
import requests
from flask import Flask, abort, flash, redirect, render_template, request, session, url_for, jsonify

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv('VEX_DATABASE_PATH', str(BASE.parent / 'vex.db'))).expanduser()
CLIENT_ID = os.getenv('DISCORD_CLIENT_ID', '')
CLIENT_SECRET = os.getenv('DISCORD_CLIENT_SECRET', '')
BOT_TOKEN = os.getenv('DISCORD_TOKEN', '')
REDIRECT_URI = os.getenv('DISCORD_REDIRECT_URI', 'http://localhost:5000/auth/callback')
SECRET_KEY = os.getenv('DASHBOARD_SECRET_KEY', '')
FOUNDERS_RAW = os.getenv('FOUNDER_USER_IDS', os.getenv('FOUNDER_USER_ID', '1529059305792471083'))
FOUNDERS = {x.strip() for x in FOUNDERS_RAW.split(',') if x.strip()}
API = 'https://discord.com/api/v10'
app = Flask(__name__)
app.secret_key = SECRET_KEY or 'CHANGE_ME_BEFORE_DEPLOYMENT'
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE','0') == '1')


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("CREATE TABLE IF NOT EXISTS dashboard_settings (guild_id TEXT PRIMARY KEY, prefix TEXT DEFAULT ',', welcome_enabled INTEGER DEFAULT 0, automod_enabled INTEGER DEFAULT 1, anti_raid_enabled INTEGER DEFAULT 0, logs_enabled INTEGER DEFAULT 0, ticket_enabled INTEGER DEFAULT 1, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    con.commit()
    return con


def discord_headers():
    return {'Authorization': f'Bot {BOT_TOKEN}'}


def current_user():
    return session.get('user')


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user(): return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapped


def founder_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user(): return redirect(url_for('login'))
        if str(current_user().get('id')) not in FOUNDERS: abort(403)
        return fn(*args, **kwargs)
    return wrapped


def get_user_guilds():
    token = session.get('access_token')
    if not token: return []
    r = requests.get(f'{API}/users/@me/guilds', headers={'Authorization': f'Bearer {token}'}, timeout=15)
    r.raise_for_status()
    user_guilds = r.json()
    bot_ids = set()
    if BOT_TOKEN:
        br = requests.get(f'{API}/users/@me/guilds', headers=discord_headers(), timeout=15)
        if br.ok: bot_ids = {g['id'] for g in br.json()}
    result = []
    for g in user_guilds:
        perms = int(g.get('permissions', '0'))
        is_admin = bool(perms & 0x8) or g.get('owner', False)
        if is_admin and (not BOT_TOKEN or g['id'] in bot_ids):
            result.append({**g, 'bot_present': g['id'] in bot_ids if BOT_TOKEN else False})
    return result

@app.context_processor
def inject_globals():
    if '_csrf' not in session: session['_csrf'] = secrets.token_urlsafe(24)
    return {'user': current_user(), 'is_founder': bool(current_user() and str(current_user().get('id')) in FOUNDERS), 'csrf_token': session['_csrf'], 'client_id': CLIENT_ID}

@app.get('/')
def home():
    return render_template('home.html')

@app.get('/login')
def login():
    if not CLIENT_ID or not CLIENT_SECRET: return render_template('setup.html'), 503
    state = secrets.token_urlsafe(24); session['oauth_state'] = state
    params = {'client_id': CLIENT_ID, 'redirect_uri': REDIRECT_URI, 'response_type': 'code', 'scope': 'identify guilds', 'state': state, 'prompt': 'consent'}
    return redirect('https://discord.com/oauth2/authorize?' + urlencode(params))

@app.get('/auth/callback')
def callback():
    if request.args.get('state') != session.pop('oauth_state', None): abort(400, 'Invalid OAuth state')
    code = request.args.get('code')
    token_r = requests.post(f'{API}/oauth2/token', data={'client_id': CLIENT_ID, 'client_secret': CLIENT_SECRET, 'grant_type': 'authorization_code', 'code': code, 'redirect_uri': REDIRECT_URI}, headers={'Content-Type':'application/x-www-form-urlencoded'}, timeout=15)
    token_r.raise_for_status(); token = token_r.json()
    me = requests.get(f'{API}/users/@me', headers={'Authorization': f"Bearer {token['access_token']}"}, timeout=15)
    me.raise_for_status()
    session.clear(); session['user'] = me.json(); session['access_token'] = token['access_token']; session['token_expires'] = int(time.time()) + token.get('expires_in', 3600)
    return redirect(url_for('servers'))

@app.get('/logout')
def logout():
    session.clear(); return redirect(url_for('home'))

@app.get('/servers')
@login_required
def servers():
    try: guilds = get_user_guilds()
    except Exception as e: flash(f'Could not load Discord servers: {e}', 'error'); guilds = []
    return render_template('servers.html', guilds=guilds)

@app.route('/dashboard/<guild_id>', methods=['GET','POST'])
@login_required
def dashboard(guild_id):
    try: allowed = {g['id'] for g in get_user_guilds()}
    except Exception: allowed = set()
    if guild_id not in allowed: abort(403)
    if request.method == 'POST':
        vals = {k: int(request.form.get(k) == 'on') for k in ['welcome_enabled','automod_enabled','anti_raid_enabled','logs_enabled','ticket_enabled']}
        prefix = request.form.get('prefix', ',').strip()[:5] or ','
        with db() as con:
            con.execute('INSERT INTO dashboard_settings (guild_id,prefix,welcome_enabled,automod_enabled,anti_raid_enabled,logs_enabled,ticket_enabled,updated_at) VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(guild_id) DO UPDATE SET prefix=excluded.prefix,welcome_enabled=excluded.welcome_enabled,automod_enabled=excluded.automod_enabled,anti_raid_enabled=excluded.anti_raid_enabled,logs_enabled=excluded.logs_enabled,ticket_enabled=excluded.ticket_enabled,updated_at=CURRENT_TIMESTAMP', (guild_id,prefix,vals['welcome_enabled'],vals['automod_enabled'],vals['anti_raid_enabled'],vals['logs_enabled'],vals['ticket_enabled']))
        flash('Dashboard preferences saved. Modules that require bot-side wiring are marked as configuration controls.', 'success')
        return redirect(url_for('dashboard', guild_id=guild_id))
    with db() as con:
        row = con.execute('SELECT * FROM dashboard_settings WHERE guild_id=?',(guild_id,)).fetchone()
    settings = dict(row) if row else {'prefix':',','welcome_enabled':0,'automod_enabled':1,'anti_raid_enabled':0,'logs_enabled':0,'ticket_enabled':1}
    return render_template('dashboard.html', guild_id=guild_id, settings=settings)

@app.get('/founder')
@founder_required
def founder():
    with db() as con:
        try: rows = con.execute('SELECT guild_id, added_by, added_at FROM whitelist ORDER BY added_at DESC').fetchall()
        except sqlite3.OperationalError: rows = []
    return render_template('founder.html', rows=rows)

@app.post('/founder/whitelist')
@founder_required
def whitelist_add():
    gid = request.form.get('guild_id','').strip()
    if not gid.isdigit() or len(gid) < 17 or len(gid) > 20:
        flash('Enter a valid Discord server ID (17–20 digits).', 'error'); return redirect(url_for('founder'))
    with db() as con:
        con.execute('CREATE TABLE IF NOT EXISTS whitelist (guild_id INTEGER PRIMARY KEY, added_by INTEGER, added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')
        con.execute('INSERT OR REPLACE INTO whitelist (guild_id,added_by) VALUES (?,?)',(int(gid),int(current_user()['id'])))
    flash(f'Server {gid} added to the VEX whitelist.', 'success'); return redirect(url_for('founder'))

@app.post('/founder/whitelist/<guild_id>/remove')
@founder_required
def whitelist_remove(guild_id):
    if not guild_id.isdigit(): abort(400)
    with db() as con:
        con.execute('DELETE FROM whitelist WHERE guild_id=?',(int(guild_id),))
    flash(f'Server {guild_id} removed from the whitelist.', 'success'); return redirect(url_for('founder'))

@app.before_request
def protect_posts():
    if request.method == 'POST':
        supplied = request.form.get('_csrf_token', '')
        if not supplied or not secrets.compare_digest(supplied, session.get('_csrf', '')): abort(400, 'Invalid form token')

@app.errorhandler(403)
def forbidden(_): return render_template('error.html', code=403, message='You do not have permission to view this page.'), 403

@app.errorhandler(404)
def not_found(_): return render_template('error.html', code=404, message='That page could not be found.'), 404

if __name__ == '__main__':
    if not SECRET_KEY or SECRET_KEY == 'CHANGE_ME_BEFORE_DEPLOYMENT': print('WARNING: Set DASHBOARD_SECRET_KEY before public deployment.')
    app.run(host='0.0.0.0', port=int(os.getenv('PORT','5000')), debug=False)
