# VEX Website

Render deployment settings:
- Runtime: Python
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`

Set secrets in Render Environment:
- DISCORD_CLIENT_ID
- DISCORD_CLIENT_SECRET
- DISCORD_REDIRECT_URI (https://YOUR-SERVICE.onrender.com/auth/callback)
- DISCORD_TOKEN
- DASHBOARD_SECRET_KEY (long random secret)
- FOUNDER_USER_IDS=1529059305792471083
- VEX_DATABASE_PATH (path to shared persistent vex.db, if configured)
- COOKIE_SECURE=1

Never commit real credentials or a .env file. Discord OAuth callback must exactly match the redirect URI configured in the Discord Developer Portal.
